//: Playground - noun: a place where people can play

import UIKit
// Mari Carmen Betancourt

/*
¿Se declara la enumeración: Velocidades y sus valores de tipo Int.?
¿Dentro de la enumeración Velocidades se cuenta con los elementos de: Apagado = 0, VelocidadBaja = 20, VelocidadMedia = 50 y VelocidadAlta = 120?
¿La enumeración Velocidades, cumple con la función inicializadora:  init( velocidadInicial : Velocidades ) El inicializador se debe asignar a self el valor de velocidadInicial?
¿Se declara la clase: Auto?
¿La clase Auto cuenta con una instancia de la enumeración Velocidades, llamada: velocidad?
¿La clase Auto implementa el método: init( )?
¿La clase Auto implementa la función: func cambioDeVelocidad( ) -> ( actual : Int, velocidadEnCadena: String) y sus reglas de ejecución?
¿Se realiza la prueba de la clase Auto, iterando 20 veces el método cambioDeVelocidad() y sus salidas se observan en la consola?
*/

/*

- El inicializador se debe asignar a self el valor de velocidadInicial

*/

var actual = 0

enum Velocidades:Int {
    case Apagado = 0
    case VelocidadBaja = 20
    case VelocidadMedia = 50
    case VelocidadAlta = 120

    init( velocidadInicial : Velocidades ) {
        self = velocidadInicial
    }

}



class Auto {
    var velocidad : Velocidades
    var valor : Int
    
    init () {
        self.velocidad = .Apagado
        valor = self.velocidad.rawValue
    }

    
func cambioDeVelocidad() -> (actual: Int, velocidadEnCadena : String) {
    let texto :  String
    valor = self.velocidad.rawValue

//    print (" \(valor) \t ")
    
    switch self.velocidad {
    case .Apagado:
        texto = "Apagado"
        self.velocidad = .VelocidadBaja

    case .VelocidadBaja:
        texto = "Velocidad Baja"
        self.velocidad = .VelocidadMedia

    case . VelocidadMedia:
        texto = "velocidad Media"
        self.velocidad = .VelocidadAlta

    case .VelocidadAlta:
        texto = "velocidad Alta"
        self.velocidad = .VelocidadMedia

    }
    return (actual : valor, velocidadEnCadena : texto)
    
    }
}

var auto = Auto()
    var resultado : (actual : Int, velocidadEnCadena : String)


for var indice in 1...20 {
    resultado = auto.cambioDeVelocidad()
    print(" \(resultado.actual) \(resultado.velocidadEnCadena) ")
}





